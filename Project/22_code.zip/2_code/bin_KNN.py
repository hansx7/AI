import math
import numpy as np
from numpy import *

def data_process(filename): #训练集的
    f = open(filename).readlines()
    type_dic = {'type_A':0,'type_B':1,'type_C':2,'type_D':3, 'type_E':4}
    data = []
    for line in f:
        temp_data = []
        line = line.strip().split(',')
        for i in range(len(line)):
            if i==1: line[i] = type_dic[line[i]]
            # if i!=12: temp_data.append(float(line[i])) #去掉第12列属性
            temp_data.append(float(line[i])) 
        data.append(temp_data)
    # data = standardlize(np.array(data))
    data = np.array(data)
    # data[:,5] = data[:,5]*2
    return data

def normalize(data):
    max1 = np.max(data, axis = 0)
    min1 = np.min(data, axis = 0)
    return (data - min1) / (max1 - min1)

def standardlize(data):
    #ipdb.set_trace()
    for i in range(data.shape[1]):
        data[:, i] = (data[:, i] - np.mean(data[:, i])) / np.std(data[:, i])
    return data

def get_X(data, types):
    if types == 'test':
        input_lists = data.T
    else:
        input_lists = data.T[0:data.shape[1]-1]
    return input_lists.T

def get_label(data):
    return np.array(data[:,-1]).reshape(-1,1)

def get_label_2(data):
    label = []
    for i in range(len(data)):
        label.append([int(data[i][-1]),0])
    return label

def split_dataset(data):
    # np.random.shuffle(data)  
    train = data[int(len(data)*0.01):]
    validation = data[:int(len(data)*0.01)]
    return train, validation

def weight():
    x = [1/0.773718, 1/0.894191, 1/0.893521, 1/0.877379, 1/0.883491, 1/0.814584, 1/0.889657, 1/0.889945, 1/0.886295, 1/0.823555, 1/0.894407, 1/0.894407, 1/0.894600]
    x = np.array(x)
    return x

def calDist(x,y):
    # dist = np.sqrt(np.sum(np.square(x-y))) #欧式
    dist = sum(abs(x-y)*weight()) #曼哈顿距离
    # dist = sum(abs(x-y))
    # dist = dot(x,y)/(linalg.norm(x)*linalg.norm(y)) #余弦夹角
    return dist

def knn_compare(data, newdata, labels, k):
    for i in range(len(data)):
        dist = calDist(data[i], newdata)
        labels[i][1] = dist
    labels = sorted(labels, key=lambda x:x[1])
    # labels = sorted(labels, key=lambda x:x[1], reverse=True) #余弦距离越大越好
    count = {}
    for i in range(k):
        key = labels[i][0]
        if key in count.keys():
            count[key] += 1/labels[i][1]
            # count[key] += 1
        else:
            count[key] = 1/labels[i][1]
            # count[key] = 1
    sortDict = ()
    sortDict = sorted(count.items(), key=lambda e:e[1], reverse=True) 
    print(sortDict[0][0])
    return sortDict[0][0]


if __name__ == "__main__":
    file = 'train.csv'
    filename = 'test.csv'
    data = data_process(file)
    test = data_process(filename)
    # train, validation = split_dataset(data)
    # print(train.shape)
    # print(validation.shape)
    train_X = get_X(data,'train')

    # valid_X = get_X(validation,'train')
    train_label = get_label_2(data)
    # valid_label = get_label(validation)
    # print(valid_label)

    result = []
    for vector in test:
        result.append(knn_compare(train_X, vector, train_label, 1))
    
    # tp = fn = tn = fp = 0
    # for j in range(len(result)):
    #     if(result[j] == 1 and valid_label[j] == 1):
    #         tp += 1
    #     if(result[j] == 0 and valid_label[j] == 1):
    #         fn += 1
    #     if(result[j] == 0 and valid_label[j] == 0):
    #         tn += 1
    #     if(result[j] == 1 and valid_label[j] == 0):
    #         fp += 1

    # recall = tp/(tp+fn)
    # precision = tp/(tp+fp)
    # print("F1: %f" % (2*precision*recall/(precision+recall)))
    np.savetxt('22_v1.csv', result, fmt='%d', delimiter='\n')
    acb= input()

'''
delete row0: 0.773718  
delete row1: 0.894191
delete row2: 0.893521
delete row3: 0.877379
delete row4: 0.883491
delete row5: 0.814584
delete row6: 0.889657
delete row7: 0.889945
delete row8: 0.886295
delete row9: 0.823555
delete row10: 0.894407
delete row11: 0.894407
delete row12: 0.894600
'''