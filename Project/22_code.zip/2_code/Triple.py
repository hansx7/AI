from numpy import *
import KNN
import readData
import numpy as np
import operator
import kMeans
word_vector={}
Label=[]
num=24000
maxIterator=500
wordMat=zeros((num,21017))
sentence=[]
word_list=[]
wordInTest={}
def loadDataSet(fileName,fileTest): 
    pos=0
    fr=open(fileTest)
    for line in fr.readlines():
        document=line.strip().split("\t\t")[1]
        sen=document.split(" <sssss> ")
        for i in range(len(sen)):
            word=sen[i].split(" ");
            for j in range(len(word)):
                if word[j].isalpha() :#and word[j] not in high_fre:
                    wordInTest[word[j]]=wordInTest.get(word[j],1)
    fr=open(fileName)
    cnt=0
    dict={}
    for line in fr.readlines():
        if cnt>=0:
            Label.append(line.strip().split("\t\t")[0]);
            document=line.strip().split("\t\t")[1]
            sentence.append(document)
            sen=document.split(" <sssss> ")
            for i in range(len(sen)):
                word=sen[i].split(" ");
                for j in range(len(word)):
                    if word[j].isalpha():
                        if word[j] not in word_vector and wordInTest.has_key(word[j])==True:
                            word_list.append(word[j])
                            dict[word[j]]=dict.get(word[j],0)+1
                            word_vector[word[j]]=pos
                            pos+=1
                            wordMat[cnt,word_vector[word[j]]]+=1
                        elif wordInTest.has_key(word[j])==True:
                            wordMat[cnt,word_vector[word[j]]]+=1
                            dict[word[j]]=dict.get(word[j],0)+1
        cnt+=1
        if cnt==num:break
    return dict
def word_cluster(clusters,maxIt=500):
    dict={}
    cluMat=zeros((3,shape(wordMat)[1]))
    cla=["LOW","MID","HIG"]
    for i in range(3):
        lab=nonzero(mat(Label)[0,:]==cla[i])[1]
        cluMat[i]=np.sum(wordMat[lab,:],axis=0)
    cluMat=cluMat/np.sum(cluMat,axis=0)
    print "clustering..."
    centroids,ass=kMeans.kMeans(cluMat.T, clusters,maxIt)
    centroids=map(int,ass[:,0].T.tolist()[0])
    writ=[]
    for i in range(len(centroids)):
        dict[word_list[i]]=centroids[i]
        writ.append(word_list[i]+':'+str(centroids[i]))
    print "finish"
    return dict
clusters=30
trainFile='MulLabelTrain.ss'
testFile='MulLabelTest.ss'
dict=loadDataSet(trainFile,testFile)
print len(dict)
reDict=word_cluster(clusters)
train,lab=readData.loadTrain(trainFile,clusters,reDict,num)
#test,l=readData.loadTrain('MulLabelTrain.ss',clusters,rrdict,num,1)
test=readData.loadTest(testFile,clusters,reDict)
an=KNN.knn(train,test,lab,40)
np.savetxt('res.csv',an,fmt="%s",delimiter="\n",newline='\n')