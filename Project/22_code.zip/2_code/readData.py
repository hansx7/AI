from numpy import *
import numpy as np
def loadTrain(fileA,clusters,reDict,num,flag=0):
    fr=open(fileA)
    cnt=0
    if flag==0:
        beg=0
        ter=num
        wordMat=zeros((num,clusters))
        TF=zeros((num,clusters))
    else:
        beg=52000
        ter=60000
        wordMat=zeros((8000,clusters))
        TF=zeros((8000,clusters))
    lab=[]
    for line in fr.readlines():
        if cnt>=beg:
            lab.append(line.strip().split("\t\t")[0]);
            document=line.strip().split("\t\t")[1]
            sen=document.split(" <sssss> ")
            for i in range(len(sen)):
                word=sen[i].split(" ");
                for j in range(len(word)):
                    if word[j].isalpha()and reDict.has_key(word[j]):
                        wordMat[cnt-beg,reDict[word[j]]]+=1
            wordMat[cnt-beg,:]=wordMat[cnt-beg,:]/sum(wordMat[cnt-beg,:])
        cnt+=1
        if cnt==ter:break
    non=nonzero(isnan(wordMat))
    wordMat[non]=0
    return wordMat,lab
def loadTest(fileA,clusters,reDict):
    fr=open(fileA)
    wordMat=zeros((8671,clusters))
    cnt=0
    for line in fr.readlines():
        document=line.strip().split("\t\t")[1]
        sen=document.split(" <sssss> ")
        for i in range(len(sen)):
            word=sen[i].split(" ");
            for j in range(len(word)):
                if word[j].isalpha() and reDict.has_key(word[j]):
                    wordMat[cnt,reDict[word[j]]]+=1               
        wordMat[cnt,:]=wordMat[cnt,:]/sum(wordMat[cnt,:])
        cnt+=1
    non=nonzero(isnan(wordMat))
    wordMat[non]=0
    #wordMat=np.hstack((wordMat,ones((len(wordMat),1))))
    return wordMat