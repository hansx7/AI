from numpy import *
import numpy as np
import operator
def knn(train,test,label,k=25):
    m=shape(train)[0]
    count=0
    answerMat=[]
    for i in range(len(test)):
        if i==len(test)-1:
            print i
        elif i%2000==0:
            print i,
        diffMat=multiply(tile(test[i],(m,1)),train)
        '''
        distances=divide(diffMat.sum(axis=1),multiply((tile(test[i],(m,1))**2).sum(axis=1)**0.5,(train**2).sum(axis=1)**0.5))
        Index=np.argsort(-distances)
        '''
        '''
        diffMat=tile(test[i],(m,1))-train
        sqDiffMat=diffMat**2
        sqDistances=sqDiffMat.sum(axis=1)
        distances=sqDistances**0.5
        Index=distances.argsort()
        '''
        diffMat=tile(test[i],(m,1))-train
        absDiffMat=np.abs(diffMat)
        distances=absDiffMat.sum(axis=1)
        Index=distances.argsort()
        judge={}
        s=test[i]
        for j in range(k):
            vote=label[Index[j]]
            t=train[Index[j]]
            nem=multiply(s,t).sum()
            dem=((s**2).sum()**0.5)*((t**2).sum()**0.5)
            judge[vote]=judge.get(vote,0)+1#/(1-nem/dem)
        result=sorted(judge.iteritems(),key=operator.itemgetter(1),reverse=True)
        answerMat.append(result[0][0])
    return answerMat
   # np.savetxt("res.csv",answerMat,fmt="%s",delimiter="\n",newline="\n")